spark.sql("""
SELECT service, COUNT(*) AS error_count
FROM logsdb.raw_logs
WHERE level = 'ERROR'
GROUP BY service
""")
.coalesce(1)
.write
.mode("overwrite")
.option("header", "true")
.csv("hdfs://namenode:8020/data/export/errors_per_service")

spark.sql("""
SELECT endpoint, AVG(responseTimeMs) AS avg_rt
FROM logsdb.raw_logs
GROUP BY endpoint
""")
.coalesce(1)
.write
.mode("overwrite")
.option("header", "true")
.csv("hdfs://namenode:8020/data/export/avg_response_time")

spark.sql("""
SELECT statusCode, COUNT(*) AS cnt
FROM logsdb.raw_logs
GROUP BY statusCode
""")
.coalesce(1)
.write
.mode("overwrite")
.option("header", "true")
.csv("hdfs://namenode:8020/data/export/status_codes")

spark.sql("""
SELECT date, hour, COUNT(*) AS total_logs
FROM logsdb.raw_logs
GROUP BY date, hour
""")
.coalesce(1)
.write
.mode("overwrite")
.option("header", "true")
.csv("hdfs://namenode:8020/data/export/traffic_per_hour")

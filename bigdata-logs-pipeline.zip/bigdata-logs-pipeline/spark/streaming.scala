import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row

val spark = SparkSession.builder()
  .appName("SyslogsStreamingKafkaToHDFS")
  .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

val schema = new StructType()
  .add("ts", StringType)
  .add("service", StringType)
  .add("level", StringType)
  .add("endpoint", StringType)
  .add("statusCode", IntegerType)
  .add("responseTimeMs", IntegerType)
  .add("host", StringType)
  .add("message", StringType)

val kafkaDf = spark.readStream
  .format("kafka")
  .option("kafka.bootstrap.servers", "kafka:9093")
  .option("subscribe", "syslogs")
  .option("startingOffsets", "earliest")
  .load()

val events = kafkaDf
  .selectExpr("CAST(value AS STRING) AS json")
  .select(from_json(col("json"), schema).as("e"))
  .select("e.*")
  .withColumn("event_time", to_timestamp(col("ts")))
  .withColumn("date", date_format(col("event_time"), "yyyy-MM-dd"))
  .withColumn("hour", date_format(col("event_time"), "HH"))
  .filter(col("event_time").isNotNull)

val rawQuery = events.writeStream
  .format("parquet")
  .option("path", "hdfs://namenode:8020/data/raw_logs")
  .option("checkpointLocation", "hdfs://namenode:8020/checkpoints/raw_logs")
  .partitionBy("date", "hour")
  .outputMode("append")
  .trigger(Trigger.ProcessingTime("10 seconds"))
  .start()

val agg = events
  .withWatermark("event_time", "2 minutes")
  .groupBy(
    window(col("event_time"), "1 minute"),
    col("service"),
    col("level")
  )
  .agg(
    count(lit(1)).as("cnt"),
    avg(col("responseTimeMs")).as("avg_rt")
  )
  .withColumn("date", date_format(col("window.start"), "yyyy-MM-dd"))
  .drop("window")

val aggQuery = agg.writeStream
  .format("parquet")
  .option("path", "hdfs://namenode:8020/data/agg_logs")
  .option("checkpointLocation", "hdfs://namenode:8020/checkpoints/agg_logs")
  .partitionBy("date")
  .outputMode("append")
  .trigger(Trigger.ProcessingTime("10 seconds"))
  .start()

val rddDemoQuery = events.writeStream.foreachBatch {
  (batchDf: Dataset[Row], batchId: Long) =>
    val counts = batchDf
      .select("level")
      .rdd
      .map(r => (r.getString(0), 1))
      .reduceByKey(_ + _)
      .collect()

    println(s"[RDD demo] batch=$batchId => " + counts.mkString(", "))
}.start()

rawQuery.awaitTermination()
aggQuery.awaitTermination()
rddDemoQuery.awaitTermination()

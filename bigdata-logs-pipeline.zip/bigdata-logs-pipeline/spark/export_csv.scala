import org.apache.spark.sql.SparkSession

val spark = SparkSession.builder()
  .appName("ExportLogsToCSV")
  .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

val df = spark.read.parquet("hdfs://namenode:8020/data/raw_logs")

df.coalesce(1)
  .write
  .mode("overwrite")
  .option("header", "true")
  .csv("hdfs://namenode:8020/data/export/csv_logs")

spark.stop()

import { Kafka } from "kafkajs";

const TOPIC = "syslogs";

// For Windows -> Docker Kafka (HOST listener)
const kafka = new Kafka({
  clientId: "syslog-producer",
  brokers: ["localhost:9092"]
});

const producer = kafka.producer();

// Helpers
function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function randInt(min, max) {
  return Math.floor(min + Math.random() * (max - min + 1));
}

// Fake log generator (realistic-ish)
function makeLog() {
  const services = ["auth", "orders", "payments", "gateway", "catalog", "search"];
  const endpoints = ["/login", "/checkout", "/pay", "/products", "/admin", "/search"];
  const hosts = ["server-1", "server-2", "server-3"];

  // Weighted level distribution
  const r = Math.random();
  const level = r < 0.80 ? "INFO" : r < 0.95 ? "WARN" : "ERROR";

  const statusCode =
    level === "ERROR" ? pick([500, 502, 503, 504]) :
    level === "WARN"  ? pick([400, 401, 403, 429]) :
                        pick([200, 201, 204]);

  // Response time: errors tend to be slower
  const responseTimeMs =
    level === "ERROR" ? randInt(800, 5000) :
    level === "WARN"  ? randInt(200, 2500) :
                        randInt(20, 1500);

  return {
    ts: new Date().toISOString(),
    host: pick(hosts),
    service: pick(services),
    level,
    endpoint: pick(endpoints),
    statusCode,
    responseTimeMs,
    message:
      level === "ERROR" ? "Something failed" :
      level === "WARN"  ? "Suspicious / slow request" :
                          "OK"
  };
}

async function run() {
  // Rate controls (safe defaults for 8GB RAM)
  const RATE_PER_SEC = parseInt(process.env.RATE_PER_SEC || "50", 10);   // logs/sec
  const BATCH_SIZE   = parseInt(process.env.BATCH_SIZE   || "50", 10);   // msgs per send()
  const PRINT_EVERY  = parseInt(process.env.PRINT_EVERY  || "5", 10);    // seconds

  await producer.connect();
  console.log(`✅ Producer connected`);
  console.log(`➡️  Topic=${TOPIC}`);
  console.log(`➡️  RATE_PER_SEC=${RATE_PER_SEC} logs/s, BATCH_SIZE=${BATCH_SIZE}`);
  console.log(`Tip: set RATE_PER_SEC=200 if your PC can handle it.`);

  let sentTotal = 0;
  let seconds = 0;

  setInterval(async () => {
    try {
      const messages = [];
      for (let i = 0; i < RATE_PER_SEC; i++) {
        messages.push({ value: JSON.stringify(makeLog()) });
      }

      // Send in chunks to reduce overhead
      for (let i = 0; i < messages.length; i += BATCH_SIZE) {
        const chunk = messages.slice(i, i + BATCH_SIZE);
        await producer.send({ topic: TOPIC, messages: chunk });
      }

      sentTotal += RATE_PER_SEC;
      seconds += 1;

      if (seconds % PRINT_EVERY === 0) {
        console.log(`📨 sentTotal=${sentTotal} logs (rate=${RATE_PER_SEC}/s)`);
      }
    } catch (err) {
      console.error("❌ send error:", err?.message || err);
    }
  }, 1000);

  // Graceful shutdown
  process.on("SIGINT", async () => {
    console.log("\nStopping producer...");
    try { await producer.disconnect(); } catch {}
    process.exit(0);
  });
}

run().catch((e) => {
  console.error("Fatal:", e);
  process.exit(1);
});
